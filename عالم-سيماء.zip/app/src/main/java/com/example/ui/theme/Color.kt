package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cheerful Child-Friendly Brand Colors for Sima's World
val SimaPink = Color(0xFFFF6F91)
val SimaMint = Color(0xFF4DDFB0)
val SimaGold = Color(0xFFFFD043)
val SimaOrange = Color(0xFFFF9671)
val SimaBlue = Color(0xFF4EADFF)
val SimaCreamBackground = Color(0xFFFFFDF6)
val SimaDarkNight = Color(0xFF181C26)
val SimaSoftCardLight = Color(0xFFFFFFFF)
val SimaSoftCardDark = Color(0xFF242A38)
