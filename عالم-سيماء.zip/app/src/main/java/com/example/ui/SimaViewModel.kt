package com.example.ui

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.os.Build
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.ChildProfile
import com.example.data.ChildRepository
import com.example.data.CompletedItem
import com.example.receiver.NotificationReceiver
import com.example.util.SoundSynthesizer
import com.example.util.TtsHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

// Screen states
enum class SimaScreen {
    HOME,
    LETTERS,
    ANIMALS,
    NUMBERS,
    COLORS,
    FRUITS_VEG,
    TRANSPORT,
    GAMES,
    REWARDS,
    PARENT_PANEL
}

// Memory Game structures
data class MemoryCard(
    val id: Int,
    val content: String,
    var isFaceUp: Boolean = false,
    var isMatched: Boolean = false
)

// Doodle line structure
data class DoodleLine(
    val points: List<androidx.compose.ui.geometry.Offset>,
    val color: Color,
    val strokeWidth: Float
)

class SimaViewModel(private val repository: ChildRepository) : ViewModel() {

    private val synthesizer = SoundSynthesizer()
    private var ttsHelper: TtsHelper? = null

    // Screen State
    private val _currentScreen = MutableStateFlow(SimaScreen.HOME)
    val currentScreen: StateFlow<SimaScreen> = _currentScreen.asStateFlow()

    // Database state flows
    val childProfile: StateFlow<ChildProfile> = repository.childProfile
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = ChildProfile()
        )

    val completedItems: StateFlow<List<CompletedItem>> = repository.completedItems
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Companion guide text
    private val _companionText = MutableStateFlow("مرحباً بك يا سيماء في عالمي الجميل! هيا بنا نتعلم ونلعب معاً! 🌟")
    val companionText: StateFlow<String> = _companionText.asStateFlow()

    // Interactive Star Animation triggers
    private val _showStarAnimation = MutableStateFlow(false)
    val showStarAnimation: StateFlow<Boolean> = _showStarAnimation.asStateFlow()

    private val _showBalloonsAnimation = MutableStateFlow(false)
    val showBalloonsAnimation: StateFlow<Boolean> = _showBalloonsAnimation.asStateFlow()

    // Sub-states: LETTERS Category
    private val _currentLetterIdx = MutableStateFlow(0)
    val currentLetterIdx: StateFlow<Int> = _currentLetterIdx.asStateFlow()

    // Sub-states: ANIMALS Category
    private val _currentAnimalIdx = MutableStateFlow(0)
    val currentAnimalIdx: StateFlow<Int> = _currentAnimalIdx.asStateFlow()
    private val _isAnimalRevealed = MutableStateFlow(false)
    val isAnimalRevealed: StateFlow<Boolean> = _isAnimalRevealed.asStateFlow()

    // Sub-states: NUMBERS Category
    private val _currentNumberIdx = MutableStateFlow(0)
    val currentNumberIdx: StateFlow<Int> = _currentNumberIdx.asStateFlow()
    private val _numberCountedList = MutableStateFlow<Set<Int>>(emptySet())
    val numberCountedList: StateFlow<Set<Int>> = _numberCountedList.asStateFlow()

    // Sub-states: COLORS Category
    private val _currentColorIdx = MutableStateFlow(0)
    val currentColorIdx: StateFlow<Int> = _currentColorIdx.asStateFlow()

    // Sub-states: FRUITS_VEG Category
    private val _currentFruitIdx = MutableStateFlow(0)
    val currentFruitIdx: StateFlow<Int> = _currentFruitIdx.asStateFlow()

    // Sub-states: TRANSPORT Category
    private val _currentTransportIdx = MutableStateFlow(0)
    val currentTransportIdx: StateFlow<Int> = _currentTransportIdx.asStateFlow()

    // Sub-states: GAMES Category
    private val _gameType = MutableStateFlow("NONE") // "MEMORY", "SHADOW", "SOUND", "BUBBLES", "COLORING"
    val gameType: StateFlow<String> = _gameType.asStateFlow()

    // 1. Memory Game State
    private val _memoryCards = MutableStateFlow<List<MemoryCard>>(emptyList())
    val memoryCards: StateFlow<List<MemoryCard>> = _memoryCards.asStateFlow()

    // 2. Shadow Matching Game State
    data class ShadowMatchItem(val id: String, val name: String, val emoji: String, val isMatched: Boolean = false)
    private val _shadowItems = MutableStateFlow<List<ShadowMatchItem>>(emptyList())
    val shadowItems: StateFlow<List<ShadowMatchItem>> = _shadowItems.asStateFlow()
    private val _shadowTargets = MutableStateFlow<List<ShadowMatchItem>>(emptyList())
    val shadowTargets: StateFlow<List<ShadowMatchItem>> = _shadowTargets.asStateFlow()
    private val _selectedShadowId = MutableStateFlow<String?>(null)
    val selectedShadowId: StateFlow<String?> = _selectedShadowId.asStateFlow()

    // 3. Animal Sound Quiz State
    private val _quizSoundAnimal = MutableStateFlow<String>("") // Correct animal sound key
    val quizSoundAnimal: StateFlow<String> = _quizSoundAnimal.asStateFlow()
    private val _quizOptions = MutableStateFlow<List<String>>(emptyList()) // Option Animal names
    val quizOptions: StateFlow<List<String>> = _quizOptions.asStateFlow()
    private val _quizAnswerState = MutableStateFlow("") // "CORRECT", "WRONG", ""
    val quizAnswerState: StateFlow<String> = _quizAnswerState.asStateFlow()

    // 4. Bubble / Number Order Sorting Game State
    private val _bubbleOrderTarget = MutableStateFlow(1)
    val bubbleOrderTarget: StateFlow<Int> = _bubbleOrderTarget.asStateFlow()
    private val _bubbleList = MutableStateFlow<List<Int>>(emptyList())
    val bubbleList: StateFlow<List<Int>> = _bubbleList.asStateFlow()

    // 5. Drawing/Coloring Canvas State
    private val _doodleLines = MutableStateFlow<List<DoodleLine>>(emptyList())
    val doodleLines: StateFlow<List<DoodleLine>> = _doodleLines.asStateFlow()
    private val _currentDoodleColor = MutableStateFlow(Color.Red)
    val currentDoodleColor: StateFlow<Color> = _currentDoodleColor.asStateFlow()
    private val _currentBrushWidth = MutableStateFlow(15f)
    val currentBrushWidth: StateFlow<Float> = _currentBrushWidth.asStateFlow()

    // Educational content dictionaries
    val lettersData = listOf(
        LetterItem("أ", "أرنب", "🐇", "أرنب يقفز في البستان"),
        LetterItem("ب", "بقرة", "🐄", "بقرة في الحقل الأخضر"),
        LetterItem("ت", "تفاحة", "🍎", "تفاحة حمراء لذيذة"),
        LetterItem("ث", "ثعلب", "🦊", "ثعلب ذكي ولطيف"),
        LetterItem("ج", "جمل", "🐫", "جمل يعيش في الصحراء"),
        LetterItem("ح", "حصان", "🐎", "حصان سريع يجري"),
        LetterItem("خ", "خروف", "🐑", "خروف صوفه أبيض ناعم"),
        LetterItem("د", "ديك", "🐓", "ديك جميل يوقظنا صباحاً"),
        LetterItem("ذ", "ذرة", "🌽", "ذرة صفراء حلوة"),
        LetterItem("ر", "رمان", "🍅", "رمان أحمر مليء بالحبيبات"),
        LetterItem("ز", "زرافة", "🦒", "زرافة رقبتها طويلة جداً"),
        LetterItem("س", "سمكة", "🐟", "سمكة ملونة تسبح في الماء"),
        LetterItem("ش", "شمس", "☀️", "شمس ساطعة تمنحنا الدفء"),
        LetterItem("ص", "صقر", "🦅", "صقر قوي يحلق عالياً"),
        LetterItem("ض", "ضفدع", "🐸", "ضفدع أخضر يقفز بالماء"),
        LetterItem("ط", "طائرة", "✈️", "طائرة تحلق في الغيوم"),
        LetterItem("ظ", "ظبي", "🦌", "ظبي سريع يعيش في الغابة"),
        LetterItem("ع", "عصفور", "🐦", "عصفور يغرد بصوت جميل"),
        LetterItem("غ", "غزالة", "🦌", "غزالة رقيقة تركض بروعة"),
        LetterItem("ف", "فراولة", "🍓", "فراولة حمراء حلوة المذاق"),
        LetterItem("ق", "قطة", "🐈", "قطة لطيفة تموء في المنزل"),
        LetterItem("ك", "كلب", "🐕", "كلب وفي يحرس البيوت"),
        LetterItem("ل", "ليمون", "🍋", "ليمون أصفر مفيد وصحي"),
        LetterItem("م", "موز", "🍌", "موز حلو ومغذي للنشاط"),
        LetterItem("ن", "نحلة", "🐝", "نحلة تصنع العسل اللذيذ"),
        LetterItem("هـ", "هلال", "🌙", "هلال ينير السماء ليلاً"),
        LetterItem("و", "وردة", "🌹", "وردة حمراء عطرها زكي"),
        LetterItem("ي", "يد", "✋", "يد نظيفة نغسلها بالصابون")
    )

    val animalsData = listOf(
        AnimalItem("بقرة", "🐄", "cow", "مووو"),
        AnimalItem("قطة", "🐈", "cat", "مياو مياو"),
        AnimalItem("عصفور", "🐦", "bird", "تغريد عذب"),
        AnimalItem("كلب", "🐕", "dog", "هوف هوف"),
        AnimalItem("بطة", "🦆", "duck", "واك واك"),
        AnimalItem("خروف", "🐑", "sheep", "بأ بأ")
    )

    val numbersData = listOf(
        NumberItem(1, "واحد", "🍎"),
        NumberItem(2, "اثنان", "🍌"),
        NumberItem(3, "ثلاثة", "🎈"),
        NumberItem(4, "أربعة", "⭐"),
        NumberItem(5, "خمسة", "🐝"),
        NumberItem(6, "ستة", "🚗"),
        NumberItem(7, "سبعة", "🐟"),
        NumberItem(8, "ثمانية", "🍓"),
        NumberItem(9, "تسعة", "🌸"),
        NumberItem(10, "عشرة", "💎")
    )

    val colorsData = listOf(
        ColorItem("أحمر", Color(0xFFE57373), "🔴"),
        ColorItem("أزرق", Color(0xFF64B5F6), "🔵"),
        ColorItem("أخضر", Color(0xFF81C784), "🟢"),
        ColorItem("أصفر", Color(0xFFFFD54F), "🟡"),
        ColorItem("وردي", Color(0xFFF06292), "🌸"),
        ColorItem("برتقالي", Color(0xFFFFB74D), "🟠"),
        ColorItem("بنفسجي", Color(0xFFBA68C8), "🟣"),
        ColorItem("أبيض", Color(0xFFECEFF1), "⚪"),
        ColorItem("أسود", Color(0xFF37474F), "⚫")
    )

    val fruitsVegData = listOf(
        FruitItem("تفاحة", "🍎", "تفاحة حمراء وصحية"),
        FruitItem("موزة", "🍌", "موزة صفراء ومغذية"),
        FruitItem("برتقالة", "🍊", "برتقالة مليئة بفيتامين سي"),
        FruitItem("فراولة", "🍓", "فراولة حمراء وحلوة"),
        FruitItem("جزرة", "🥕", "جزرة تقوي النظر"),
        FruitItem("خيار", "🥒", "خيار طازج ومقرمش"),
        FruitItem("طماطم", "🍅", "طماطم حمراء لذيذة"),
        FruitItem("بطيخ", "🍉", "بطيخ بارد ومنعش")
    )

    val transportData = listOf(
        TransportItem("سيارة", "🚗", "بييب بييب!", "سيارة سريعة تسير على الطريق"),
        TransportItem("باص", "🚌", "باص المدرسة الكبير", "ينقل الأطفال إلى المدرسة بأمان"),
        TransportItem("قطار", "🚂", "تووووت تووووت!", "قطار طويل يسير على السكة الحديدية"),
        TransportItem("طائرة", "✈️", "طائرة تحلق عالياً في الغيوم", "طائرة سريعة تطير عالياً في السماء"),
        TransportItem("سفينة", "🚢", "سفينة تبحر في البحر الواسع", "سفينة كبيرة تحمل البضائع والركاب في المحيط")
    )

    fun initTts(context: Context) {
        if (ttsHelper == null) {
            ttsHelper = TtsHelper(context) {
                // Speak welcome message upon initialization complete
                speakCompanionText()
            }
        }
    }

    fun navigateTo(screen: SimaScreen) {
        _currentScreen.value = screen
        synthesizer.playClick()
        
        // Dynamic companion prompts upon screen entry
        val childName = childProfile.value.name
        val welcomeMsg = when (screen) {
            SimaScreen.HOME -> "مرحباً بك مجدداً يا $childName! ماذا تريدين أن نتعلم اليوم؟ ✨"
            SimaScreen.LETTERS -> "هيا لنتعلم الحروف العربية يا $childName! ما هو حرفكِ المفضل؟ 📖"
            SimaScreen.ANIMALS -> "أهلاً بكِ في حديقة الحيوانات يا $childName! اضغطي على أي حيوان لتسمعي صوته! 🐄"
            SimaScreen.NUMBERS -> "لنعد الأرقام معاً يا $childName! واحد، اثنان، ثلاثة... 🔢"
            SimaScreen.COLORS -> "عالم الألوان ممتع جداً يا $childName! لنكتشف الألوان الجميلة! 🎨"
            SimaScreen.FRUITS_VEG -> "اممم! الفواكه والخضروات لذيذة ومفيدة جداً لصحتكِ يا $childName! 🍎"
            SimaScreen.TRANSPORT -> "بببببييب! لنكتشف وسائل النقل السريعة والمثيرة يا $childName! 🚗"
            SimaScreen.GAMES -> "حان وقت اللعب والمرح يا $childName! أي لعبة نلعب اليوم؟ 🧩"
            SimaScreen.REWARDS -> "انظري للجوائز الرائعة التي جمعتيها بذكائكِ يا $childName! أنا فخورة بكِ! 🏆"
            SimaScreen.PARENT_PANEL -> "بوابة الأهل المخصصة لإعدادات تطبيق عالم سيماء."
        }
        _companionText.value = welcomeMsg
        speak(welcomeMsg)
    }

    fun speak(text: String) {
        if (childProfile.value.soundsEnabled) {
            ttsHelper?.speak(text)
        }
    }

    fun speakCompanionText() {
        speak(_companionText.value)
    }

    fun stopSpeaking() {
        ttsHelper?.stop()
    }

    // ---------------- LETTERS ACTION ----------------
    fun selectLetter(idx: Int) {
        if (idx in lettersData.indices) {
            _currentLetterIdx.value = idx
            val letter = lettersData[idx]
            val profile = childProfile.value
            val textToSay = "حرف ${letter.char}... ${letter.char} مثل ${letter.word}... ${letter.description}."
            _companionText.value = textToSay
            speak(textToSay)
            synthesizer.playClick()

            viewModelScope.launch {
                repository.completeItem("letter", letter.char)
            }
        }
    }

    fun completeLetterActivity() {
        synthesizer.playBellSuccess()
        _showStarAnimation.value = true
        val profile = childProfile.value
        val congratsText = "أحسنتِ يا ${profile.name}! لقد تعلمتِ حرف ${lettersData[_currentLetterIdx.value].char} وحصلتِ على نجمة! ⭐"
        _companionText.value = congratsText
        speak(congratsText)

        viewModelScope.launch {
            repository.addStarAndCheckLevel(profile)
        }
    }

    // ---------------- ANIMALS ACTION ----------------
    fun selectAnimal(idx: Int) {
        if (idx in animalsData.indices) {
            _currentAnimalIdx.value = idx
            _isAnimalRevealed.value = false
            val animal = animalsData[idx]
            val profile = childProfile.value
            synthesizer.playClick()

            val initialPrompt = "يا ${profile.name}، هل تعرفين ما هذا الحيوان الجميل؟ 🐄"
            _companionText.value = initialPrompt
            speak(initialPrompt)

            // Auto-reveal after 3 seconds with animal sound and name
            viewModelScope.launch {
                kotlinx.coroutines.delay(3000)
                _isAnimalRevealed.value = true
                synthesizer.playAnimalSound(animal.soundKey)
                
                val revealText = "إنها ${animal.name}! ${animal.name} تقول: ${animal.mimicText}. هل تستطيعين تقليد صوتها؟"
                _companionText.value = revealText
                speak(revealText)
                
                repository.completeItem("animal", animal.name)
            }
        }
    }

    fun awardAnimalStar() {
        synthesizer.playStarTwinkle()
        _showStarAnimation.value = true
        val profile = childProfile.value
        val congratsText = "أنتِ مدهشة يا ${profile.name}! خذي هذه النجمة لتفاعلكِ الممتاز! ⭐"
        _companionText.value = congratsText
        speak(congratsText)

        viewModelScope.launch {
            repository.addStarAndCheckLevel(profile)
        }
    }

    // ---------------- NUMBERS ACTION ----------------
    fun selectNumber(idx: Int) {
        if (idx in numbersData.indices) {
            _currentNumberIdx.value = idx
            _numberCountedList.value = emptySet()
            val num = numbersData[idx]
            val profile = childProfile.value
            val text = "هذا هو الرقم ${num.num}... ${num.text}! اضغطي على ال${num.emoji} لنعدهم معاً!"
            _companionText.value = text
            speak(text)
            synthesizer.playClick()

            viewModelScope.launch {
                repository.completeItem("number", num.num.toString())
            }
        }
    }

    fun countNumberItem(itemIdx: Int) {
        val currentSet = _numberCountedList.value
        if (itemIdx !in currentSet) {
            val newSet = currentSet + itemIdx
            _numberCountedList.value = newSet
            synthesizer.playPop()
            
            // Speak standard Arabic counter
            val counterWord = when (newSet.size) {
                1 -> "واحد"
                2 -> "اثنان"
                3 -> "ثلاثة"
                4 -> "أربعة"
                5 -> "خمسة"
                6 -> "ستة"
                7 -> "سبعة"
                8 -> "ثمانية"
                9 -> "تسعة"
                10 -> "عشرة"
                else -> "${newSet.size}"
            }
            speak(counterWord)

            // If fully counted
            val targetNum = numbersData[_currentNumberIdx.value].num
            if (newSet.size == targetNum) {
                viewModelScope.launch {
                    kotlinx.coroutines.delay(800)
                    synthesizer.playBellSuccess()
                    _showBalloonsAnimation.value = true
                    val profile = childProfile.value
                    val textToSay = "رائع يا ${profile.name}! ${numbersData[_currentNumberIdx.value].text}... أحسنتِ!"
                    _companionText.value = textToSay
                    speak(textToSay)
                    repository.addStarAndCheckLevel(profile)
                }
            }
        }
    }

    // ---------------- COLORS ACTION ----------------
    fun selectColor(idx: Int) {
        if (idx in colorsData.indices) {
            _currentColorIdx.value = idx
            val color = colorsData[idx]
            val profile = childProfile.value
            val text = "هذا هو اللون ال${color.name} ${color.emoji}! انظري كم هو جميل وساطع!"
            _companionText.value = text
            speak(text)
            synthesizer.playClick()

            viewModelScope.launch {
                repository.completeItem("color", color.name)
            }
        }
    }

    fun completeColorActivity() {
        synthesizer.playStarTwinkle()
        _showStarAnimation.value = true
        val profile = childProfile.value
        val text = "تلوين رائع ومبدع يا ${profile.name}! تستحقين نجمة ذهبية لموهبتكِ الفنية! 🎨"
        _companionText.value = text
        speak(text)

        viewModelScope.launch {
            repository.addStarAndCheckLevel(profile)
        }
    }

    // ---------------- FRUITS_VEG ACTION ----------------
    fun selectFruit(idx: Int) {
        if (idx in fruitsVegData.indices) {
            _currentFruitIdx.value = idx
            val fruit = fruitsVegData[idx]
            val profile = childProfile.value
            val text = "${fruit.name} ${fruit.emoji}... ${fruit.description}! مفيدة وصحية وممتازة لجسمكِ الصغير!"
            _companionText.value = text
            speak(text)
            synthesizer.playClick()

            viewModelScope.launch {
                repository.completeItem("fruit_veg", fruit.name)
            }
        }
    }

    fun completeFruitActivity() {
        synthesizer.playBellSuccess()
        _showStarAnimation.value = true
        val profile = childProfile.value
        val text = "أحسنتِ يا ${profile.name}! الفواكه والخضروات تصنع أبطالاً أقوياء مثلكِ! ⭐"
        _companionText.value = text
        speak(text)

        viewModelScope.launch {
            repository.addStarAndCheckLevel(profile)
        }
    }

    // ---------------- TRANSPORT ACTION ----------------
    fun selectTransport(idx: Int) {
        if (idx in transportData.indices) {
            _currentTransportIdx.value = idx
            val tr = transportData[idx]
            val profile = childProfile.value
            val text = "${tr.name} ${tr.emoji}! صوتها هو: ${tr.soundWaveText}. ${tr.description}."
            _companionText.value = text
            speak(text)
            synthesizer.playClick()

            viewModelScope.launch {
                // Play matching custom synthetic vehicle horn
                if (tr.name == "قطار") {
                    synthesizer.playAnimalSound("sheep") // train whistle proxy
                } else if (tr.name == "سيارة" || tr.name == "باص") {
                    synthesizer.playAnimalSound("duck") // horn buzz proxy
                } else {
                    synthesizer.playClick()
                }
                repository.completeItem("transport", tr.name)
            }
        }
    }

    // ---------------- GAMES SCREEN CONTROLS ----------------
    fun startNewGame(type: String) {
        _gameType.value = type
        synthesizer.playClick()
        val profile = childProfile.value

        when (type) {
            "MEMORY" -> {
                val base = listOf("🐄", "🐈", "🐦", "🍎", "🍌", "🚗")
                val doubled = (base + base).shuffled().mapIndexed { i, emoji ->
                    MemoryCard(id = i, content = emoji)
                }
                _memoryCards.value = doubled
                val msg = "يا ${profile.name}! لنمرح مع لعبة ذاكرة الصور! ابحثي عن الأشكال المتطابقة!"
                _companionText.value = msg
                speak(msg)
            }
            "SHADOW" -> {
                val source = listOf(
                    ShadowMatchItem("1", "قطة", "🐈"),
                    ShadowMatchItem("2", "تفاحة", "🍎"),
                    ShadowMatchItem("3", "سيارة", "🚗")
                )
                _shadowItems.value = source.shuffled()
                _shadowTargets.value = source.shuffled()
                _selectedShadowId.value = null
                val msg = "لعبة مطابقة الظلال! اضغطي على الشكل ثم اضغطي على ظله المناسب يا ${profile.name}!"
                _companionText.value = msg
                speak(msg)
            }
            "SOUND" -> {
                setupSoundQuiz()
            }
            "BUBBLES" -> {
                _bubbleOrderTarget.value = 1
                _bubbleList.value = (1..5).shuffled()
                val msg = "هيا فجري الفقاعات بالترتيب من ١ إلى ٥ يا ${profile.name}! لتطير البالونات!"
                _companionText.value = msg
                speak(msg)
            }
            "COLORING" -> {
                _doodleLines.value = emptyList()
                val msg = "لوحة التلوين الحرة! اختاري الألوان وارسمي أجمل اللوحات بأصابعكِ يا ${profile.name}! 🎨"
                _companionText.value = msg
                speak(msg)
            }
            else -> {
                _companionText.value = "اختر لعبة تعليمية ممتعة لنلعبها معاً!"
            }
        }
    }

    // MEMORY MATCHING GAME CLICK
    fun clickMemoryCard(cardId: Int) {
        val current = _memoryCards.value.toMutableList()
        val clickedCard = current.firstOrNull { it.id == cardId } ?: return
        if (clickedCard.isFaceUp || clickedCard.isMatched) return

        synthesizer.playClick()
        clickedCard.isFaceUp = true
        _memoryCards.value = current

        // Check if another card is face up
        val faceUpCards = current.filter { it.isFaceUp && !it.isMatched }
        if (faceUpCards.size == 2) {
            viewModelScope.launch {
                kotlinx.coroutines.delay(800)
                if (faceUpCards[0].content == faceUpCards[1].content) {
                    // Match found!
                    faceUpCards[0].isMatched = true
                    faceUpCards[1].isMatched = true
                    synthesizer.playPop()
                    _memoryCards.value = current.toList()
                    
                    // Check if game won
                    if (current.all { it.isMatched }) {
                        synthesizer.playBellSuccess()
                        _showBalloonsAnimation.value = true
                        val profile = childProfile.value
                        val winMsg = "رائع ومبهر يا ${profile.name}! لقد حللتِ لغز الذاكرة بالكامل! خذي نجمة! ⭐"
                        _companionText.value = winMsg
                        speak(winMsg)
                        repository.addStarAndCheckLevel(profile)
                    }
                } else {
                    // No match, turn face down
                    faceUpCards[0].isFaceUp = false
                    faceUpCards[1].isFaceUp = false
                    _memoryCards.value = current.toList()
                }
            }
        }
    }

    // SHADOW GAME CLICK
    fun selectShadowItem(id: String) {
        synthesizer.playClick()
        _selectedShadowId.value = id
    }

    fun selectShadowTarget(id: String) {
        val selected = _selectedShadowId.value ?: return
        synthesizer.playClick()

        if (selected == id) {
            // Correct match
            val currentItems = _shadowItems.value.map {
                if (it.id == id) it.copy(isMatched = true) else it
            }
            _shadowItems.value = currentItems
            _selectedShadowId.value = null
            synthesizer.playPop()

            // Check if game won
            if (currentItems.all { it.isMatched }) {
                viewModelScope.launch {
                    synthesizer.playBellSuccess()
                    _showStarAnimation.value = true
                    val profile = childProfile.value
                    val congrats = "مذهلة يا ${profile.name}! طابقتِ جميع الصور بظلالها الصحيحة! خذي نجمتكِ! ⭐"
                    _companionText.value = congrats
                    speak(congrats)
                    repository.addStarAndCheckLevel(profile)
                }
            }
        } else {
            // Incorrect match
            speak("حاولي مرة أخرى يا ${childProfile.value.name}")
        }
    }

    // ANIMAL SOUND QUIZ SETUP & ACTION
    private fun setupSoundQuiz() {
        val randomAnimal = animalsData.random()
        _quizSoundAnimal.value = randomAnimal.soundKey
        
        val options = mutableListOf(randomAnimal.name)
        val otherAnimals = animalsData.filter { it.name != randomAnimal.name }.shuffled()
        if (otherAnimals.size >= 2) {
            options.add(otherAnimals[0].name)
            options.add(otherAnimals[1].name)
        }
        _quizOptions.value = options.shuffled()
        _quizAnswerState.value = ""

        val profile = childProfile.value
        val msg = "استمعي جيداً يا ${profile.name}! من هو الحيوان الذي يصنع هذا الصوت؟"
        _companionText.value = msg
        speak(msg)
        
        viewModelScope.launch {
            kotlinx.coroutines.delay(2000)
            synthesizer.playAnimalSound(randomAnimal.soundKey)
        }
    }

    fun playQuizSound() {
        synthesizer.playAnimalSound(_quizSoundAnimal.value)
    }

    fun answerSoundQuiz(animalName: String) {
        synthesizer.playClick()
        val correctAnswer = animalsData.firstOrNull { it.soundKey == _quizSoundAnimal.value }?.name ?: return
        val profile = childProfile.value

        if (animalName == correctAnswer) {
            _quizAnswerState.value = "CORRECT"
            synthesizer.playBellSuccess()
            _showStarAnimation.value = true
            val congrats = "أنتِ ذكية وممتازة يا ${profile.name}! إجابة صحيحة، إنه صوت ال$correctAnswer! خذي نجمة! ⭐"
            _companionText.value = congrats
            speak(congrats)
            viewModelScope.launch {
                repository.addStarAndCheckLevel(profile)
            }
        } else {
            _quizAnswerState.value = "WRONG"
            val retry = "حاولي مجدداً يا ${profile.name}! اسمعي الصوت وحزري مرة أخرى."
            _companionText.value = retry
            speak(retry)
        }
    }

    fun nextQuizQuestion() {
        setupSoundQuiz()
    }

    // BUBBLES COUNTING POP
    fun popBubble(number: Int) {
        val target = _bubbleOrderTarget.value
        if (number == target) {
            synthesizer.playPop()
            _bubbleOrderTarget.value = target + 1
            speak("$number")

            if (number == 5) {
                // Game Won
                viewModelScope.launch {
                    kotlinx.coroutines.delay(600)
                    synthesizer.playBellSuccess()
                    _showBalloonsAnimation.value = true
                    val profile = childProfile.value
                    val congrats = "رائعة يا ${profile.name}! رتبتِ الأرقام من ١ إلى ٥ ببراعة فائقة! ⭐"
                    _companionText.value = congrats
                    speak(congrats)
                    repository.addStarAndCheckLevel(profile)
                }
            }
        } else {
            // Wrong bubble popped
            speak("ابحثي عن الرقم ${_bubbleOrderTarget.value} يا ${childProfile.value.name}")
        }
    }

    // COLORING CANVAS OPERATIONS
    fun addDoodlePoint(point: androidx.compose.ui.geometry.Offset, isNewPath: Boolean) {
        val currentList = _doodleLines.value.toMutableList()
        if (isNewPath || currentList.isEmpty()) {
            currentList.add(DoodleLine(listOf(point), _currentDoodleColor.value, _currentBrushWidth.value))
        } else {
            val lastLine = currentList.removeAt(currentList.size - 1)
            currentList.add(lastLine.copy(points = lastLine.points + point))
        }
        _doodleLines.value = currentList
    }

    fun setDoodleColor(color: Color) {
        synthesizer.playClick()
        _currentDoodleColor.value = color
    }

    fun clearDoodle() {
        synthesizer.playClick()
        _doodleLines.value = emptyList()
    }

    // ---------------- PARENTAL SETTINGS ----------------
    fun saveSettings(name: String, age: Int, dailyTimeLimit: Int, music: Boolean, sounds: Boolean) {
        synthesizer.playBellSuccess()
        viewModelScope.launch {
            val profile = childProfile.value.copy(
                name = name.ifBlank { "سيماء" },
                age = age,
                dailyTimeLimitMinutes = dailyTimeLimit,
                musicEnabled = music,
                soundsEnabled = sounds
            )
            repository.updateProfile(profile)
            _companionText.value = "تم حفظ الإعدادات بنجاح! مرحباً بك يا ${profile.name}! 🌸"
            speak("تم حفظ الإعدادات بنجاح")
        }
    }

    fun resetProgress() {
        synthesizer.playClick()
        viewModelScope.launch {
            repository.resetAllProgress()
            _currentLetterIdx.value = 0
            _currentAnimalIdx.value = 0
            _currentNumberIdx.value = 0
            _currentColorIdx.value = 0
            _currentFruitIdx.value = 0
            _currentTransportIdx.value = 0
            _companionText.value = "أهلاً بكِ مجدداً يا سيماء! لنبدأ مغامرتنا الجميلة من جديد! 🌟"
            speak("تمت إعادة ضبط المغامرة من جديد")
        }
    }

    fun triggerOfflineNotificationNow(context: Context) {
        synthesizer.playPop()
        scheduleNotification(
            context,
            1, // Schedule in 1 minute
            "يا ${childProfile.value.name} 🌸 أين أنتِ؟",
            "لقد اشتقنا إليك كثيراً! هيا نلعب ونتعلم أشياء جديدة وممتعة في عالمكِ الرائع."
        )
    }

    private fun scheduleNotification(context: Context, delayMinutes: Int, title: String, message: String) {
        try {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
            val intent = Intent(context, NotificationReceiver::class.java).apply {
                putExtra("title", title)
                putExtra("message", message)
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                UUID.randomUUID().hashCode(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val triggerTime = System.currentTimeMillis() + (delayMinutes * 60 * 1000L)
            alarmManager.set(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun dismissStarAnimation() {
        _showStarAnimation.value = false
    }

    fun dismissBalloonsAnimation() {
        _showBalloonsAnimation.value = false
    }

    override fun onCleared() {
        super.onCleared()
        ttsHelper?.shutdown()
    }
}

// Data structures
data class LetterItem(val char: String, val word: String, val emoji: String, val description: String)
data class AnimalItem(val name: String, val emoji: String, val soundKey: String, val mimicText: String)
data class NumberItem(val num: Int, val text: String, val emoji: String)
data class ColorItem(val name: String, val colorValue: Color, val emoji: String)
data class FruitItem(val name: String, val emoji: String, val description: String)
data class TransportItem(val name: String, val emoji: String, val soundWaveText: String, val description: String)


// ViewModel Factory
class SimaViewModelFactory(private val repository: ChildRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SimaViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return SimaViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
