package com.example.util

import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale

class TtsHelper(context: Context, private val onInitCompleted: () -> Unit = {}) {
    private var tts: TextToSpeech? = null
    private var isReady = false

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val localeResult = tts?.setLanguage(Locale("ar"))
                if (localeResult == TextToSpeech.LANG_MISSING_DATA || localeResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                    Log.e("TtsHelper", "Arabic language is not supported or missing data on this device")
                } else {
                    isReady = true
                    tts?.setPitch(1.2f) // slightly higher pitch for friendly child voice!
                    tts?.setSpeechRate(0.85f) // slightly slower speech rate for kids to hear clearly
                    onInitCompleted()
                }
            } else {
                Log.e("TtsHelper", "Failed to initialize TextToSpeech")
            }
        }
    }

    fun speak(text: String) {
        if (isReady) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "SimaWorldSpeech")
        } else {
            Log.w("TtsHelper", "TTS is not ready yet. Content: $text")
        }
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
