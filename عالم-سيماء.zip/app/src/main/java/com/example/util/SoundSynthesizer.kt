package com.example.util

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.sin

class SoundSynthesizer {
    private val scope = CoroutineScope(Dispatchers.Default)

    /**
     * Play a synthesized sound effect using standard Android AudioTrack.
     */
    private fun playPcm(sampleRate: Int, samples: FloatArray) {
        scope.launch {
            try {
                // Convert FloatArray (-1.0 to 1.0) to ShortArray (-32768 to 32767)
                val pcmShorts = ShortArray(samples.size)
                for (i in samples.indices) {
                    val s = (samples[i] * 32767).toInt()
                    pcmShorts[i] = s.coerceIn(-32768, 32767).toShort()
                }

                val bufferSize = pcmShorts.size * 2
                val audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(bufferSize)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                audioTrack.write(pcmShorts, 0, pcmShorts.size)
                audioTrack.play()
                
                // Monitor track and release it once played
                scope.launch {
                    try {
                        val durationMs = (pcmShorts.size.toFloat() / sampleRate * 1000).toLong()
                        kotlinx.coroutines.delay(durationMs + 200)
                        audioTrack.stop()
                        audioTrack.release()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    /**
     * Sound effect: Pop (like a balloon popping)
     */
    fun playPop() {
        val sampleRate = 22050
        val duration = 0.12f // 120ms
        val totalSamples = (sampleRate * duration).toInt()
        val samples = FloatArray(totalSamples)

        // Generate frequency sweep downwards (from 800Hz to 80Hz) with exponential decay
        for (i in 0 until totalSamples) {
            val t = i.toFloat() / sampleRate
            val progress = t / duration
            val freq = 800f - (progress * 720f)
            val envelope = 1.0f - progress
            samples[i] = (sin(2.0 * Math.PI * freq * t) * envelope * 0.5f).toFloat()
        }
        playPcm(sampleRate, samples)
    }

    /**
     * Sound effect: Star collection / Twinkle
     */
    fun playStarTwinkle() {
        val sampleRate = 22050
        val duration = 0.5f // 500ms
        val totalSamples = (sampleRate * duration).toInt()
        val samples = FloatArray(totalSamples)

        // Arpeggio sound: G5 (784Hz), B5 (988Hz), D6 (1175Hz), G6 (1568Hz) rising
        for (i in 0 until totalSamples) {
            val t = i.toFloat() / sampleRate
            val progress = t / duration
            
            // Switch frequency based on progress
            val freq = when {
                progress < 0.25f -> 784f
                progress < 0.50f -> 988f
                progress < 0.75f -> 1175f
                else -> 1568f
            }
            val envelope = 1.0f - progress
            samples[i] = (sin(2.0 * Math.PI * freq * t) * envelope * 0.4f).toFloat()
        }
        playPcm(sampleRate, samples)
    }

    /**
     * Sound effect: Bell chime / Success (e.g. correct answer)
     */
    fun playBellSuccess() {
        val sampleRate = 22050
        val duration = 0.6f
        val totalSamples = (sampleRate * duration).toInt()
        val samples = FloatArray(totalSamples)

        // Harmonic chime: fundamental 880Hz + overtone 1760Hz
        for (i in 0 until totalSamples) {
            val t = i.toFloat() / sampleRate
            val progress = t / duration
            val envelope = Math.exp(-6.0 * progress).toFloat()
            val wave = sin(2.0 * Math.PI * 880.0 * t) + 0.5 * sin(2.0 * Math.PI * 1760.0 * t)
            samples[i] = (wave * envelope * 0.3f).toFloat()
        }
        playPcm(sampleRate, samples)
    }

    /**
     * Sound effect: Click
     */
    fun playClick() {
        val sampleRate = 22050
        val duration = 0.05f
        val totalSamples = (sampleRate * duration).toInt()
        val samples = FloatArray(totalSamples)

        for (i in 0 until totalSamples) {
            val t = i.toFloat() / sampleRate
            val envelope = 1.0f - (t / duration)
            samples[i] = (sin(2.0 * Math.PI * 440.0 * t) * envelope * 0.2f).toFloat()
        }
        playPcm(sampleRate, samples)
    }

    /**
     * Sound effect: Animal mimic / Comical sound
     */
    fun playAnimalSound(type: String) {
        val sampleRate = 22050
        val duration = when (type) {
            "cow" -> 0.8f
            "cat" -> 0.4f
            "bird" -> 0.3f
            "dog" -> 0.25f
            "duck" -> 0.3f
            "sheep" -> 0.6f
            else -> 0.4f
        }
        val totalSamples = (sampleRate * duration).toInt()
        val samples = FloatArray(totalSamples)

        for (i in 0 until totalSamples) {
            val t = i.toFloat() / sampleRate
            val progress = t / duration
            val wave = when (type) {
                "cow" -> {
                    // Low humming frequency sweep (120Hz down to 80Hz) with vibration
                    val freq = 120f - (progress * 40f)
                    val vibrato = 1f + 0.1f * sin(2.0 * Math.PI * 15.0 * t).toFloat()
                    sin(2.0 * Math.PI * freq * t) * vibrato
                }
                "cat" -> {
                    // Meow sound: sweep upwards (400Hz to 700Hz) then downwards (700Hz to 500Hz)
                    val freq = if (progress < 0.6f) {
                        400f + (progress / 0.6f * 300f)
                    } else {
                        700f - ((progress - 0.6f) / 0.4f * 200f)
                    }
                    sin(2.0 * Math.PI * freq * t)
                }
                "bird" -> {
                    // Chirping sound: fast sweep upwards (1500Hz to 2500Hz) repeated
                    val localT = (t * 4) % 0.1f
                    val freq = 1500f + (localT / 0.1f * 1000f)
                    sin(2.0 * Math.PI * freq * t)
                }
                "dog" -> {
                    // Bark sound: quick downwards sweep (300Hz down to 100Hz)
                    val freq = 300f - (progress * 200f)
                    sin(2.0 * Math.PI * freq * t)
                }
                "duck" -> {
                    // Quack: harsh buzz wave around 250Hz
                    val freq = 250f
                    val sine = sin(2.0 * Math.PI * freq * t)
                    // Make it buzzy by clipping/clamping
                    sine.coerceIn(-0.6, 0.6) * 1.5
                }
                "sheep" -> {
                    // Baaa: vibrating medium tone
                    val freq = 220f
                    val vibrato = 1f + 0.25f * sin(2.0 * Math.PI * 18.0 * t).toFloat()
                    sin(2.0 * Math.PI * freq * t) * vibrato
                }
                else -> {
                    sin(2.0 * Math.PI * 440.0 * t)
                }
            }
            val envelope = if (progress < 0.1f) {
                progress / 0.1f
            } else {
                1.0f - ((progress - 0.1f) / 0.9f)
            }
            samples[i] = (wave.toFloat() * envelope * 0.4f)
        }
        playPcm(sampleRate, samples)
    }
}
