package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ChildProfile
import com.example.data.ChildRepository
import com.example.data.SimaDatabase
import com.example.ui.*
import com.example.ui.theme.SimaTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize SQLite Room database, DAO, and Repository pattern
        val database = SimaDatabase.getDatabase(applicationContext)
        val repository = ChildRepository(database.childDao())

        // Standard dynamic view model instantiation
        val viewModel: SimaViewModel by viewModels {
            SimaViewModelFactory(repository)
        }

        setContent {
            SimaTheme {
                // Initialize TTS Engine offline
                val context = LocalContext.current
                LaunchedEffect(Unit) {
                    viewModel.initTts(context)
                }

                // Edge-to-edge root scaffold container with dynamic child-friendly colors
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        SimaBottomBar(viewModel = viewModel)
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        MaterialTheme.colorScheme.background,
                                        MaterialTheme.colorScheme.background.copy(alpha = 0.9f)
                                    )
                                )
                            )
                    ) {
                        // Game Main Screen Selector
                        SimaScreenContainer(viewModel = viewModel)

                        // Floating particles and confetti animations
                        CelebrationOverlay(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

// Retro-compatible greeting helper for existing testing profiles
@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "مرحباً بكِ يا $name في عالم سيماء!",
        modifier = modifier.padding(16.dp),
        fontSize = 24.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
        textAlign = TextAlign.Center
    )
}

@Composable
fun SimaBottomBar(viewModel: SimaViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val profile by viewModel.childProfile.collectAsStateWithLifecycle()

    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        NavigationBarItem(
            icon = { Icon(Icons.Default.Home, contentDescription = "الرئيسية") },
            label = { Text("الرئيسية", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
            selected = currentScreen == SimaScreen.HOME,
            onClick = { viewModel.navigateTo(SimaScreen.HOME) },
            modifier = Modifier.testTag("nav_home")
        )
        NavigationBarItem(
            icon = { Icon(Icons.Default.PlayArrow, contentDescription = "الألعاب") },
            label = { Text("ألعاب", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
            selected = currentScreen == SimaScreen.GAMES,
            onClick = { viewModel.navigateTo(SimaScreen.GAMES) },
            modifier = Modifier.testTag("nav_games")
        )
        NavigationBarItem(
            icon = { Icon(Icons.Default.Star, contentDescription = "الجوائز") },
            label = { Text("الجوائز", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
            selected = currentScreen == SimaScreen.REWARDS,
            onClick = { viewModel.navigateTo(SimaScreen.REWARDS) },
            modifier = Modifier.testTag("nav_rewards")
        )
        NavigationBarItem(
            icon = { Icon(Icons.Default.Settings, contentDescription = "الأهل") },
            label = { Text("الأهل", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
            selected = currentScreen == SimaScreen.PARENT_PANEL,
            onClick = { viewModel.navigateTo(SimaScreen.PARENT_PANEL) },
            modifier = Modifier.testTag("nav_parents")
        )
    }
}

@Composable
fun SimaScreenContainer(viewModel: SimaViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()

    AnimatedContent(
        targetState = currentScreen,
        transitionSpec = {
            slideInHorizontally { width -> width } + fadeIn() togetherWith
                    slideOutHorizontally { width -> -width } + fadeOut()
        },
        label = "screen_transition"
    ) { screen ->
        when (screen) {
            SimaScreen.HOME -> HomeScreen(viewModel)
            SimaScreen.LETTERS -> LettersScreen(viewModel)
            SimaScreen.ANIMALS -> AnimalsScreen(viewModel)
            SimaScreen.NUMBERS -> NumbersScreen(viewModel)
            SimaScreen.COLORS -> ColorsScreen(viewModel)
            SimaScreen.FRUITS_VEG -> FruitsScreen(viewModel)
            SimaScreen.TRANSPORT -> TransportScreen(viewModel)
            SimaScreen.GAMES -> GamesScreen(viewModel)
            SimaScreen.REWARDS -> RewardsScreen(viewModel)
            SimaScreen.PARENT_PANEL -> ParentSettingsScreen(viewModel)
        }
    }
}

// ---------------- HOME SCREEN ----------------
@Composable
fun HomeScreen(viewModel: SimaViewModel) {
    val profile by viewModel.childProfile.collectAsStateWithLifecycle()
    val companionText by viewModel.companionText.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // High-contrast cheerful status bar
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "مرحباً، البطلة ${profile.name}! 🌟",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "المستوى: ${profile.level}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                    )
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "${profile.starsCount}",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                    Icon(
                        Icons.Default.Star,
                        contentDescription = "نجوم",
                        tint = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }

        // Companion robot guide "سمسم"
        item {
            CompanionGuideWidget(viewModel, companionText)
        }

        // Category Cards Grid for Learning Sections
        item {
            Text(
                text = "ماذا تريدين أن نتعلم اليوم؟",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                textAlign = TextAlign.Right
            )
        }

        item {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    CategoryCard(
                        title = "الحروف العربية",
                        subtitle = "أ، ب، ت...",
                        emoji = "📖",
                        color = Color(0xFFFF85A1),
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.navigateTo(SimaScreen.LETTERS) }
                    )
                    CategoryCard(
                        title = "عالم الحيوانات",
                        subtitle = "أصوات ورسوم",
                        emoji = "🐄",
                        color = Color(0xFF4DDFB0),
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.navigateTo(SimaScreen.ANIMALS) }
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    CategoryCard(
                        title = "الأرقام الجميلة",
                        subtitle = "١، ٢، ٣...",
                        emoji = "🔢",
                        color = Color(0xFFFFD043),
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.navigateTo(SimaScreen.NUMBERS) }
                    )
                    CategoryCard(
                        title = "الألوان الزاهية",
                        subtitle = "تلوين ومرح",
                        emoji = "🎨",
                        color = Color(0xFFFF9671),
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.navigateTo(SimaScreen.COLORS) }
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    CategoryCard(
                        title = "الفواكه والخضار",
                        subtitle = "أكل صحي",
                        emoji = "🍎",
                        color = Color(0xFF4EADFF),
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.navigateTo(SimaScreen.FRUITS_VEG) }
                    )
                    CategoryCard(
                        title = "وسائل النقل",
                        subtitle = "سيارة وطائرة",
                        emoji = "🚗",
                        color = Color(0xFFB39DDB),
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.navigateTo(SimaScreen.TRANSPORT) }
                    )
                }
            }
        }
    }
}

@Composable
fun CompanionGuideWidget(viewModel: SimaViewModel, text: String) {
    val infiniteTransition = rememberInfiniteTransition(label = "robot_anim")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f), RoundedCornerShape(24.dp))
            .padding(16.dp)
            .clickable { viewModel.speakCompanionText() },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Animated Little Companion "سمسم"
        Box(
            modifier = Modifier
                .size(72.dp)
                .scale(scale)
                .background(MaterialTheme.colorScheme.tertiary, CircleShape)
                .padding(4.dp),
            contentAlignment = Alignment.Center
        ) {
            // Drawn cute cartoon face on Canvas
            Canvas(modifier = Modifier.fillMaxSize()) {
                // Happy blinking eyes
                drawCircle(Color.White, radius = 10f, center = Offset(size.width * 0.35f, size.height * 0.45f))
                drawCircle(Color.White, radius = 10f, center = Offset(size.width * 0.65f, size.height * 0.45f))
                drawCircle(Color.Black, radius = 5f, center = Offset(size.width * 0.35f, size.height * 0.45f))
                drawCircle(Color.Black, radius = 5f, center = Offset(size.width * 0.65f, size.height * 0.45f))
                
                // Rosy cheeks
                drawCircle(Color(0xFFFF8A8A), radius = 6f, center = Offset(size.width * 0.22f, size.height * 0.58f))
                drawCircle(Color(0xFFFF8A8A), radius = 6f, center = Offset(size.width * 0.78f, size.height * 0.58f))
                
                // Smiling mouth
                val path = Path().apply {
                    moveTo(size.width * 0.4f, size.height * 0.65f)
                    quadraticTo(
                        size.width * 0.5f, size.height * 0.8f,
                        size.width * 0.6f, size.height * 0.65f
                    )
                }
                drawPath(path, Color(0xFF4A148C), style = Stroke(width = 4f, cap = StrokeCap.Round))
            }
        }

        // Arabic speech bubble
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = text,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                textAlign = TextAlign.Right,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            )
        }
    }
}

@Composable
fun CategoryCard(
    title: String,
    subtitle: String,
    emoji: String,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = color),
        shape = RoundedCornerShape(28.dp),
        modifier = modifier
            .height(130.dp)
            .shadow(6.dp, RoundedCornerShape(28.dp))
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.Start
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(Color.White.copy(alpha = 0.35f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(emoji, fontSize = 24.sp)
            }
            Column {
                Text(title, fontSize = 16.sp, fontWeight = FontWeight.Black, color = Color.White)
                Text(subtitle, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White.copy(alpha = 0.9f))
            }
        }
    }
}

// ---------------- ARABIC LETTERS SCREEN ----------------
@Composable
fun LettersScreen(viewModel: SimaViewModel) {
    val currentLetterIdx by viewModel.currentLetterIdx.collectAsStateWithLifecycle()
    val letters = viewModel.lettersData
    val activeLetter = letters[currentLetterIdx]

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Back Button
        ScreenBackButton(onBack = { viewModel.navigateTo(SimaScreen.HOME) })

        // Horizontal letter carousel selection
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 8.dp)
        ) {
            items(letters.size) { idx ->
                val isSelected = idx == currentLetterIdx
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(
                            if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
                        )
                        .border(
                            2.dp,
                            if (isSelected) Color.Transparent else MaterialTheme.colorScheme.primary.copy(
                                alpha = 0.3f
                            ),
                            CircleShape
                        )
                        .clickable { viewModel.selectLetter(idx) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = letters[idx].char,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black,
                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onBackground
                    )
                }
            }
        }

        // Active letter display
        Card(
            shape = RoundedCornerShape(32.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .shadow(12.dp, RoundedCornerShape(32.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Giant Letter
                val letterScale by animateFloatAsState(targetValue = 1.2f, animationSpec = spring(), label = "letter")
                Text(
                    text = activeLetter.char,
                    fontSize = 110.sp,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .scale(letterScale)
                        .clickable { viewModel.speakCompanionText() }
                )

                // Word details and emoji representation
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        activeLetter.emoji,
                        fontSize = 72.sp,
                        modifier = Modifier
                            .scale(1.1f)
                            .padding(8.dp)
                    )
                    Text(
                        text = "${activeLetter.char} مثل ${activeLetter.word}",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = activeLetter.description,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                // Reward verification buttons
                Button(
                    onClick = { viewModel.completeLetterActivity() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("complete_letter_btn")
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("لقد تعلمتُ هذا الحرف! 🌟", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ---------------- ANIMAL WORLD SCREEN ----------------
@Composable
fun AnimalsScreen(viewModel: SimaViewModel) {
    val currentAnimalIdx by viewModel.currentAnimalIdx.collectAsStateWithLifecycle()
    val isRevealed by viewModel.isAnimalRevealed.collectAsStateWithLifecycle()
    val animals = viewModel.animalsData
    val activeAnimal = animals[currentAnimalIdx]

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        ScreenBackButton(onBack = { viewModel.navigateTo(SimaScreen.HOME) })

        // Horizontal navigation
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    val prev = if (currentAnimalIdx - 1 < 0) animals.size - 1 else currentAnimalIdx - 1
                    viewModel.selectAnimal(prev)
                },
                modifier = Modifier.background(MaterialTheme.colorScheme.surface, CircleShape)
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "السابق")
            }
            Text(
                text = "عالم الحيوانات الكرتوني 🐄",
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.primary
            )
            IconButton(
                onClick = {
                    val next = (currentAnimalIdx + 1) % animals.size
                    viewModel.selectAnimal(next)
                },
                modifier = Modifier.background(MaterialTheme.colorScheme.surface, CircleShape)
            ) {
                Icon(Icons.Default.ArrowForward, contentDescription = "التالي")
            }
        }

        // Main Animal Display Container
        Card(
            shape = RoundedCornerShape(32.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .shadow(8.dp, RoundedCornerShape(32.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (isRevealed) activeAnimal.emoji else "❓",
                    fontSize = 110.sp,
                    modifier = Modifier
                        .scale(1.2f)
                        .padding(16.dp)
                        .clickable { viewModel.selectAnimal(currentAnimalIdx) }
                )

                AnimatedVisibility(
                    visible = isRevealed,
                    enter = scaleIn() + fadeIn(),
                    exit = scaleOut() + fadeOut()
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = activeAnimal.name,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "تقول: ${activeAnimal.mimicText}",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }

                // Interactive child action to test and repeat sounds
                Button(
                    onClick = { viewModel.awardAnimalStar() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("mimic_animal_btn")
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Star, contentDescription = "نجمة", tint = Color.Black)
                        Text("لقد قلدتُ صوتها! خذي نجمة ⭐", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                    }
                }
            }
        }
    }
}

// ---------------- NUMBERS SCREEN ----------------
@Composable
fun NumbersScreen(viewModel: SimaViewModel) {
    val currentNumberIdx by viewModel.currentNumberIdx.collectAsStateWithLifecycle()
    val countedList by viewModel.numberCountedList.collectAsStateWithLifecycle()
    val numbers = viewModel.numbersData
    val activeNumber = numbers[currentNumberIdx]

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        ScreenBackButton(onBack = { viewModel.navigateTo(SimaScreen.HOME) })

        // Horizontal selections
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(numbers.size) { idx ->
                val isSelected = idx == currentNumberIdx
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(
                            if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
                        )
                        .clickable { viewModel.selectNumber(idx) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${numbers[idx].num}",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onBackground
                    )
                }
            }
        }

        // Active counting board
        Card(
            shape = RoundedCornerShape(32.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .shadow(8.dp, RoundedCornerShape(32.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "${activeNumber.num}",
                        fontSize = 64.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = activeNumber.text,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }

                // Interactive counting items
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 60.dp),
                    modifier = Modifier
                        .weight(1f)
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalArrangement = Arrangement.Center
                ) {
                    items(activeNumber.num) { idx ->
                        val isCounted = idx in countedList
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .padding(4.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    if (isCounted) MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f)
                                    else Color.Transparent
                                )
                                .border(
                                    2.dp,
                                    if (isCounted) MaterialTheme.colorScheme.secondary
                                    else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.15f),
                                    RoundedCornerShape(16.dp)
                                )
                                .clickable { viewModel.countNumberItem(idx) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = activeNumber.emoji,
                                fontSize = 36.sp,
                                modifier = Modifier.scale(if (isCounted) 0.8f else 1.1f)
                            )
                        }
                    }
                }

                Text(
                    text = "اضغطي على العناصر لعدها معاً! (${countedList.size} من ${activeNumber.num})",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                )
            }
        }
    }
}

// ---------------- COLORS SCREEN ----------------
@Composable
fun ColorsScreen(viewModel: SimaViewModel) {
    val currentColorIdx by viewModel.currentColorIdx.collectAsStateWithLifecycle()
    val colors = viewModel.colorsData
    val activeColor = colors[currentColorIdx]

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        ScreenBackButton(onBack = { viewModel.navigateTo(SimaScreen.HOME) })

        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(colors.size) { idx ->
                val isSelected = idx == currentColorIdx
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(colors[idx].colorValue)
                        .border(
                            4.dp,
                            if (isSelected) MaterialTheme.colorScheme.primary else Color.White,
                            CircleShape
                        )
                        .clickable { viewModel.selectColor(idx) }
                )
            }
        }

        // Active Color Showcase Card
        Card(
            shape = RoundedCornerShape(32.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .shadow(8.dp, RoundedCornerShape(32.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Large Colored Circle representation
                Box(
                    modifier = Modifier
                        .size(160.dp)
                        .shadow(6.dp, CircleShape)
                        .background(activeColor.colorValue, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(activeColor.emoji, fontSize = 64.sp)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = activeColor.name,
                        fontSize = 36.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "اللون الجميل اللامع! ✨",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                }

                Button(
                    onClick = { viewModel.completeColorActivity() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("color_success_btn")
                ) {
                    Text("لقد تذكرتُ هذا اللون! 🌟", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ---------------- FRUITS SCREEN ----------------
@Composable
fun FruitsScreen(viewModel: SimaViewModel) {
    val currentFruitIdx by viewModel.currentFruitIdx.collectAsStateWithLifecycle()
    val fruits = viewModel.fruitsVegData
    val activeFruit = fruits[currentFruitIdx]

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        ScreenBackButton(onBack = { viewModel.navigateTo(SimaScreen.HOME) })

        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(fruits.size) { idx ->
                val isSelected = idx == currentFruitIdx
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
                        )
                        .clickable { viewModel.selectFruit(idx) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(fruits[idx].emoji, fontSize = 28.sp)
                }
            }
        }

        Card(
            shape = RoundedCornerShape(32.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .shadow(8.dp, RoundedCornerShape(32.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = activeFruit.emoji,
                    fontSize = 110.sp,
                    modifier = Modifier
                        .scale(1.1f)
                        .clickable { viewModel.selectFruit(currentFruitIdx) }
                )

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = activeFruit.name,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = activeFruit.description,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }

                Button(
                    onClick = { viewModel.completeFruitActivity() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                ) {
                    Text("سأتناول أكلاً صحياً! 🍎", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ---------------- TRANSPORT SCREEN ----------------
@Composable
fun TransportScreen(viewModel: SimaViewModel) {
    val currentTransportIdx by viewModel.currentTransportIdx.collectAsStateWithLifecycle()
    val transportItems = viewModel.transportData
    val activeTransport = transportItems[currentTransportIdx]

    // Animation values for moving vectors across screen
    var runAnimationTrigger by remember { mutableStateOf(0) }
    val horizontalOffset by animateFloatAsState(
        targetValue = if (runAnimationTrigger % 2 == 0) 0f else 250f,
        animationSpec = tween(1500, easing = LinearOutSlowInEasing),
        label = "transport_motion"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        ScreenBackButton(onBack = { viewModel.navigateTo(SimaScreen.HOME) })

        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(transportItems.size) { idx ->
                val isSelected = idx == currentTransportIdx
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
                        )
                        .clickable {
                            runAnimationTrigger = 0
                            viewModel.selectTransport(idx)
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(transportItems[idx].emoji, fontSize = 28.sp)
                }
            }
        }

        Card(
            shape = RoundedCornerShape(32.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .shadow(8.dp, RoundedCornerShape(32.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Animated landscape track
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color(0xFFE3F2FD))
                        .padding(16.dp)
                ) {
                    Text(
                        text = activeTransport.emoji,
                        fontSize = 80.sp,
                        modifier = Modifier
                            .offset(x = horizontalOffset.dp)
                            .align(Alignment.CenterStart)
                            .clickable {
                                runAnimationTrigger++
                                viewModel.selectTransport(currentTransportIdx)
                            }
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = activeTransport.name,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = activeTransport.description,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                Button(
                    onClick = { runAnimationTrigger++ },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                ) {
                    Text("انطلق يا ${activeTransport.name}! 🚀", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ---------------- EDUCATIONAL GAMES SCREEN ----------------
@Composable
fun GamesScreen(viewModel: SimaViewModel) {
    val gameType by viewModel.gameType.collectAsStateWithLifecycle()

    if (gameType == "NONE") {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            ScreenBackButton(onBack = { viewModel.navigateTo(SimaScreen.HOME) })

            Text(
                text = "ألعاب سيماء التعليمية 🧩",
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.primary
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(1),
                modifier = Modifier.fillMaxWidth().weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    GameMenuCard("🧠 ذاكرة الصور (Memory)", "مطابقة أشكال الحيوانات المضحكة المتشابهة", "🍎", Color(0xFFE57373)) {
                        viewModel.startNewGame("MEMORY")
                    }
                }
                item {
                    GameMenuCard("👥 مطابقة الظلال (Shadow Match)", "مطابقة الأشكال والألوان بظلها المناسب", "🐈", Color(0xFF81C784)) {
                        viewModel.startNewGame("SHADOW")
                    }
                }
                item {
                    GameMenuCard("🔊 حزر الصوت (Sound Quiz)", "معرفة الحيوان الصحيح من صوته الطبيعي", "🐕", Color(0xFFFFD54F)) {
                        viewModel.startNewGame("SOUND")
                    }
                }
                item {
                    GameMenuCard("🧼 فرقعة الفقاعات (Bubble Pop)", "ترتيب الأرقام الصاعدة من ١ إلى ٥", "🔢", Color(0xFF64B5F6)) {
                        viewModel.startNewGame("BUBBLES")
                    }
                }
                item {
                    GameMenuCard("🎨 المرسم الحر (Drawing Pad)", "ارسمي ولوني بأصابعكِ بحرية تامة", "🖌️", Color(0xFFF06292)) {
                        viewModel.startNewGame("COLORING")
                    }
                }
            }
        }
    } else {
        // Individual Game Containers
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.startNewGame("NONE") },
                    modifier = Modifier.background(MaterialTheme.colorScheme.surface, CircleShape)
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "قائمة الألعاب")
                }
                Text(
                    text = when (gameType) {
                        "MEMORY" -> "ذاكرة الصور"
                        "SHADOW" -> "مطابقة الظلال"
                        "SOUND" -> "حزر الصوت"
                        "BUBBLES" -> "ترتيب الفقاعات"
                        "COLORING" -> "المرسم الحر"
                        else -> ""
                    },
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(48.dp))
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(24.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(16.dp)
            ) {
                when (gameType) {
                    "MEMORY" -> MemoryGameContainer(viewModel)
                    "SHADOW" -> ShadowGameContainer(viewModel)
                    "SOUND" -> SoundGameContainer(viewModel)
                    "BUBBLES" -> BubblesGameContainer(viewModel)
                    "COLORING" -> ColoringGameContainer(viewModel)
                }
            }
        }
    }
}

@Composable
fun GameMenuCard(title: String, desc: String, emoji: String, color: Color, onClick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.15f)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .border(2.dp, color.copy(alpha = 0.4f), RoundedCornerShape(24.dp))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .background(color, RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(emoji, fontSize = 28.sp)
            }
            Column {
                Text(title, fontSize = 16.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.onBackground)
                Text(desc, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
            }
        }
    }
}

// 1. MEMORY MATCH GAME
@Composable
fun MemoryGameContainer(viewModel: SimaViewModel) {
    val cards by viewModel.memoryCards.collectAsStateWithLifecycle()

    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(cards) { card ->
            Box(
                modifier = Modifier
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        if (card.isFaceUp || card.isMatched) MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f)
                        else MaterialTheme.colorScheme.primary
                    )
                    .border(
                        2.dp,
                        if (card.isMatched) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary,
                        RoundedCornerShape(16.dp)
                    )
                    .clickable { viewModel.clickMemoryCard(card.id) },
                contentAlignment = Alignment.Center
            ) {
                if (card.isFaceUp || card.isMatched) {
                    Text(card.content, fontSize = 32.sp)
                } else {
                    Text("❓", fontSize = 24.sp, color = Color.White)
                }
            }
        }
    }
}

// 2. SHADOW MATCH GAME
@Composable
fun ShadowGameContainer(viewModel: SimaViewModel) {
    val items by viewModel.shadowItems.collectAsStateWithLifecycle()
    val targets by viewModel.shadowTargets.collectAsStateWithLifecycle()
    val selectedId by viewModel.selectedShadowId.collectAsStateWithLifecycle()

    Row(modifier = Modifier.fillMaxSize()) {
        // Items list (Left)
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("الشكل 🎨", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            items.forEach { item ->
                if (!item.isMatched) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                if (selectedId == item.id) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                            .border(
                                2.dp,
                                if (selectedId == item.id) MaterialTheme.colorScheme.primary else Color.Transparent,
                                RoundedCornerShape(16.dp)
                            )
                            .clickable { viewModel.selectShadowItem(item.id) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(item.emoji, fontSize = 36.sp)
                    }
                } else {
                    Spacer(modifier = Modifier.size(72.dp))
                }
            }
        }

        // Silhouette Shadow List (Right)
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("الظل المناسب 👤", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            targets.forEach { target ->
                if (!target.isMatched) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.Black.copy(alpha = 0.85f))
                            .clickable { viewModel.selectShadowTarget(target.id) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text("👤", fontSize = 24.sp, color = Color.White.copy(alpha = 0.4f))
                    }
                } else {
                    Spacer(modifier = Modifier.size(72.dp))
                }
            }
        }
    }
}

// 3. ANIMAL SOUND GAME
@Composable
fun SoundGameContainer(viewModel: SimaViewModel) {
    val quizOptions by viewModel.quizOptions.collectAsStateWithLifecycle()
    val answerState by viewModel.quizAnswerState.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Button(
            onClick = { viewModel.playQuizSound() },
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
            modifier = Modifier.size(100.dp),
            shape = CircleShape
        ) {
            Icon(Icons.Default.PlayArrow, contentDescription = "استمع للصوت", modifier = Modifier.size(48.dp))
        }

        Text("اسمعي جيداً! من هو صاحب هذا الصوت؟ 🔊", fontSize = 16.sp, fontWeight = FontWeight.Bold)

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            quizOptions.forEach { name ->
                Button(
                    onClick = { viewModel.answerSoundQuiz(name) },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Text(name, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        if (answerState == "CORRECT") {
            Button(
                onClick = { viewModel.nextQuizQuestion() },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text("السؤال التالي 🌟", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// 4. BUBBLES POP ORDER GAME
@Composable
fun BubblesGameContainer(viewModel: SimaViewModel) {
    val bubbles by viewModel.bubbleList.collectAsStateWithLifecycle()
    val targetNumber by viewModel.bubbleOrderTarget.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "الهدف الحالي: اضغطي على الرقم $targetNumber! 🧼",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        Row(
            modifier = Modifier.fillMaxWidth().weight(1f),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            bubbles.forEach { num ->
                val popped = num < targetNumber
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(
                            if (popped) Color.Transparent
                            else Color(0xFFE0F7FA).copy(alpha = 0.8f)
                        )
                        .border(
                            2.dp,
                            if (popped) Color.Transparent else Color(0xFF00ACC1),
                            CircleShape
                        )
                        .clickable { viewModel.popBubble(num) },
                    contentAlignment = Alignment.Center
                ) {
                    if (!popped) {
                        Text("$num", fontSize = 28.sp, fontWeight = FontWeight.Black, color = Color(0xFF006064))
                    }
                }
            }
        }
    }
}

// 5. COLORING CANVAS GAME
@Composable
fun ColoringGameContainer(viewModel: SimaViewModel) {
    val lines by viewModel.doodleLines.collectAsStateWithLifecycle()
    val activeColor by viewModel.currentDoodleColor.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf(Color.Red, Color.Blue, Color.Green, Color.Yellow, Color.Magenta, Color.Black).forEach { col ->
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(col)
                        .border(
                            2.dp,
                            if (activeColor == col) MaterialTheme.colorScheme.primary else Color.White,
                            CircleShape
                        )
                        .clickable { viewModel.setDoodleColor(col) }
                )
            }
            Spacer(modifier = Modifier.weight(1f))
            Button(
                onClick = { viewModel.clearDoodle() },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                contentPadding = PaddingValues(horizontal = 12.dp)
            ) {
                Text("مسح", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Tracing canvas board
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White)
                .border(2.dp, Color.LightGray, RoundedCornerShape(16.dp))
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            viewModel.addDoodlePoint(offset, isNewPath = true)
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            viewModel.addDoodlePoint(change.position, isNewPath = false)
                        }
                    )
                }
        ) {
            lines.forEach { line ->
                val points = line.points
                if (points.size > 1) {
                    val path = Path().apply {
                        moveTo(points[0].x, points[0].y)
                        for (i in 1 until points.size) {
                            lineTo(points[i].x, points[i].y)
                        }
                    }
                    drawPath(
                        path = path,
                        color = line.color,
                        style = Stroke(width = line.strokeWidth, cap = StrokeCap.Round)
                    )
                }
            }
        }
    }
}

// ---------------- REWARDS SCREEN ----------------
@Composable
fun RewardsScreen(viewModel: SimaViewModel) {
    val profile by viewModel.childProfile.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            ScreenBackButton(onBack = { viewModel.navigateTo(SimaScreen.HOME) })
        }

        item {
            Text(
                "لوحة التميز والجوائز 🏆",
                fontSize = 22.sp,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.primary
            )
        }

        // Stats summary row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                RewardMetricCard("النجوم الذهبية", "${profile.starsCount} ⭐", Color(0xFFFFD043), Modifier.weight(1f))
                RewardMetricCard("الأوسمة والميداليات", "${profile.medalsCount} 🏅", Color(0xFF4DDFB0), Modifier.weight(1f))
            }
        }

        // Certificate Section (Gold Border, High-Fidelity Arabic style)
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFCF9F2)),
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(10.dp, RoundedCornerShape(24.dp))
                    .border(3.dp, Color(0xFFD4AF37), RoundedCornerShape(24.dp)) // Royal gold border
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        "🏆 شُهَادَة تَمَيُّز وَتَفَوُّق 🏆",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF996515),
                        textAlign = TextAlign.Center
                    )
                    Text(
                        "تُمنح هذه الشهادة بكل فخر واعتزاز للبطلة الذكية:",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.DarkGray,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        profile.name,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                    Text(
                        "لمشاركتها الممتازة وتفوقها الرائع في تعلم الحروف، الأرقام، والألوان بكل ذكاء وشغف في تطبيق عالم سيماء.",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        "المساعد سمسم يفخر بكِ! 🌟",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        }

        // Interactive Balloon popping
        item {
            Button(
                onClick = {
                    viewModel.completeLetterActivity() // Triggers sound and balloon overlays!
                },
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text("أطلقي بالونات الاحتفال! 🎈", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun RewardMetricCard(title: String, score: String, color: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.height(100.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.15f)),
        border = BorderStroke(2.dp, color)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
            Text(score, fontSize = 24.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.onBackground)
        }
    }
}

// ---------------- PARENTAL SETTINGS SCREEN ----------------
@Composable
fun ParentSettingsScreen(viewModel: SimaViewModel) {
    val profile by viewModel.childProfile.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // Parental Security Lock Gate
    var isGateUnlocked by remember { mutableStateOf(false) }
    var gateInput by remember { mutableStateOf("") }
    val gateAnswer = "٨" // Arabic "8" for (5 + 3 = 8)

    // Form states
    var nameState by remember { mutableStateOf("") }
    var ageState by remember { mutableStateOf("") }
    var limitState by remember { mutableStateOf("") }
    var musicState by remember { mutableStateOf(true) }
    var soundState by remember { mutableStateOf(true) }

    LaunchedEffect(profile) {
        nameState = profile.name
        ageState = profile.age.toString()
        limitState = profile.dailyTimeLimitMinutes.toString()
        musicState = profile.musicEnabled
        soundState = profile.soundsEnabled
    }

    // Permission launcher for notifications
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            Toast.makeText(context, "تم تفعيل إشعارات عالم سيماء!", Toast.LENGTH_SHORT).show()
        }
    }

    if (!isGateUnlocked) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Default.Lock, contentDescription = "قفل الأهل", modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                "بوابة الأهل المخصصة 👨‍👩‍👧",
                fontSize = 22.sp,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                "الرجاء حل هذه المسألة الحسابية البسيطة للمتابعة والتأكد من هويتك كأحد الوالدين:",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Gray,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(vertical = 12.dp)
            )

            Text("ما هو حاصل جمع:  ٥ + ٣ = ؟", fontSize = 24.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
            
            Spacer(modifier = Modifier.height(16.dp))

            // Cheerful Child-proof keypad options
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                listOf("٦", "٧", "٨", "٩").forEach { option ->
                    Button(
                        onClick = {
                            if (option == gateAnswer) {
                                isGateUnlocked = true
                            } else {
                                Toast.makeText(context, "إجابة خاطئة! حاول مجدداً.", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(option, fontSize = 20.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }
    } else {
        // Gate is unlocked, display actual settings and analytics
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            ScreenBackButton(onBack = { viewModel.navigateTo(SimaScreen.HOME) })

            Text(
                "إعدادات الوالدين ومتابعة التقدم 📊",
                fontSize = 22.sp,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.primary
            )

            // Progress tracking analytics box
            Card(
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("إحصائيات تقدم طفلكِ الحالية:", fontSize = 16.sp, fontWeight = FontWeight.Black)
                    HorizontalProgressIndicator(label = "مستوى الذكاء العام", score = profile.level, max = 10, color = Color(0xFFFFD043))
                    HorizontalProgressIndicator(label = "النجوم المكتسبة", score = profile.starsCount, max = 100, color = Color(0xFFFF6F91))
                    HorizontalProgressIndicator(label = "الميداليات الفخرية", score = profile.medalsCount, max = 10, color = Color(0xFF4DDFB0))
                }
            }

            // Child profile settings editing form
            Card(
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("تعديل ملف طفلكِ الشخصي:", fontSize = 16.sp, fontWeight = FontWeight.Black)

                    OutlinedTextField(
                        value = nameState,
                        onValueChange = { nameState = it },
                        label = { Text("اسم الطفل المفضل") },
                        modifier = Modifier.fillMaxWidth().testTag("child_name_input"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = ageState,
                        onValueChange = { ageState = it },
                        label = { Text("عمر الطفل (سنوات)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = limitState,
                        onValueChange = { limitState = it },
                        label = { Text("وقت التعلم اليومي المحدد (دقائق)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Audio preferences togglers
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("موسيقى الخلفية الهادئة", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Switch(checked = musicState, onCheckedChange = { musicState = it })
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("مساعدات النطق والأصوات الطبيعية", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Switch(checked = soundState, onCheckedChange = { soundState = it })
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.saveSettings(
                                    nameState,
                                    ageState.toIntOrNull() ?: 4,
                                    limitState.toIntOrNull() ?: 30,
                                    musicState,
                                    soundState
                                )
                                Toast.makeText(context, "تم حفظ الإعدادات بنجاح!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f).testTag("save_settings_btn")
                        ) {
                            Text("حفظ التعديلات", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                viewModel.resetProgress()
                                Toast.makeText(context, "تم تصفير التقدم بالكامل!", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("إعادة ضبط المغامرة", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Offline Notification triggers testing box
            Card(
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("اختبار إشعارات عالم سيماء (بدون إنترنت) 🔔", fontSize = 16.sp, fontWeight = FontWeight.Black)
                    Text(
                        "اضغط لتجربة إرسال تنبيه فوري لطيف بعد دقيقة كإشعار محلي كامل بدون اتصال إنترنت:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray
                    )
                    Button(
                        onClick = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            }
                            viewModel.triggerOfflineNotificationNow(context)
                            Toast.makeText(context, "تمت جدولة إشعار تذكيري لطيف بنجاح!", Toast.LENGTH_LONG).show()
                        },
                        modifier = Modifier.fillMaxWidth().testTag("trigger_notification_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                    ) {
                        Text("إرسال الإشعار التذكيري الآن", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun HorizontalProgressIndicator(label: String, score: Int, max: Int, color: Color) {
    val progress = if (max > 0) score.toFloat() / max else 0f
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text("$score / $max", fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        LinearProgressIndicator(
            progress = progress.coerceIn(0f, 1f),
            color = color,
            trackColor = color.copy(alpha = 0.15f),
            modifier = Modifier.fillMaxWidth().height(10.dp).clip(CircleShape)
        )
    }
}

// Custom simple Screen Back button
@Composable
fun ScreenBackButton(onBack: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Start
    ) {
        IconButton(
            onClick = { onBack() },
            modifier = Modifier.background(MaterialTheme.colorScheme.surface, CircleShape)
        ) {
            Icon(Icons.Default.ArrowBack, contentDescription = "رجوع")
        }
    }
}

// Overlay animations for successes and balloon pops
@Composable
fun CelebrationOverlay(viewModel: SimaViewModel) {
    val showStar by viewModel.showStarAnimation.collectAsStateWithLifecycle()
    val showBalloons by viewModel.showBalloonsAnimation.collectAsStateWithLifecycle()

    if (showStar) {
        LaunchedEffect(Unit) {
            delay(2200)
            viewModel.dismissStarAnimation()
        }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.35f))
                .clickable { viewModel.dismissStarAnimation() },
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                val infiniteTransition = rememberInfiniteTransition(label = "star_pop")
                val rotate by infiniteTransition.animateFloat(
                    initialValue = 0f,
                    targetValue = 360f,
                    animationSpec = infiniteRepeatable(tween(3000, easing = LinearEasing)),
                    label = "rotate"
                )
                Icon(
                    Icons.Default.Star,
                    contentDescription = "نجمة ذهبية",
                    tint = Color(0xFFFFD043),
                    modifier = Modifier
                        .size(140.dp)
                        .rotate(rotate)
                )
                Text(
                    "أحسنتِ يا ذكية! ⭐",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )
            }
        }
    }

    if (showBalloons) {
        LaunchedEffect(Unit) {
            delay(2500)
            viewModel.dismissBalloonsAnimation()
        }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.4f))
                .clickable { viewModel.dismissBalloonsAnimation() },
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    "🎈 🌸 🎈 🌸 🎈",
                    fontSize = 56.sp,
                    modifier = Modifier.padding(16.dp)
                )
                Text(
                    "ممتازة يا بطلة! بالونات ممتعة!",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}
