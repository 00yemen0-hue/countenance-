package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "completed_items")
data class CompletedItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val category: String, // e.g. "letter", "animal", "number", "color", "fruit_veg", "transport"
    val itemId: String,   // e.g. "أ", "بقرة", "5", etc.
    val timestamp: Long = System.currentTimeMillis()
)
