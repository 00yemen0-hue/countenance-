package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ChildDao {
    @Query("SELECT * FROM child_profile WHERE id = 1 LIMIT 1")
    fun getProfile(): Flow<ChildProfile?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: ChildProfile)

    @Query("SELECT * FROM completed_items ORDER BY timestamp DESC")
    fun getAllCompletedItems(): Flow<List<CompletedItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCompletedItem(item: CompletedItem)

    @Query("DELETE FROM completed_items")
    suspend fun clearAllProgress()
}
