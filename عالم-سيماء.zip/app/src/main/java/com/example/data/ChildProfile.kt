package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "child_profile")
data class ChildProfile(
    @PrimaryKey val id: Int = 1,
    val name: String = "سيماء",
    val age: Int = 4,
    val dailyTimeLimitMinutes: Int = 30,
    val musicEnabled: Boolean = true,
    val soundsEnabled: Boolean = true,
    val starsCount: Int = 0,
    val medalsCount: Int = 0,
    val level: Int = 1,
    val lastActiveTimestamp: Long = System.currentTimeMillis()
)
