package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class ChildRepository(private val childDao: ChildDao) {
    val childProfile: Flow<ChildProfile> = childDao.getProfile().map { it ?: ChildProfile() }
    val completedItems: Flow<List<CompletedItem>> = childDao.getAllCompletedItems()

    suspend fun updateProfile(profile: ChildProfile) {
        childDao.insertProfile(profile)
    }

    suspend fun completeItem(category: String, itemId: String) {
        val newItem = CompletedItem(category = category, itemId = itemId)
        childDao.insertCompletedItem(newItem)
    }

    suspend fun addStarAndCheckLevel(currentProfile: ChildProfile) {
        val newStars = currentProfile.starsCount + 1
        // Level up every 10 stars!
        val newLevel = (newStars / 10) + 1
        val newMedals = if (newLevel > currentProfile.level) currentProfile.medalsCount + 1 else currentProfile.medalsCount
        updateProfile(
            currentProfile.copy(
                starsCount = newStars,
                level = newLevel,
                medalsCount = newMedals
            )
        )
    }

    suspend fun resetAllProgress() {
        childDao.clearAllProgress()
        updateProfile(ChildProfile())
    }
}
